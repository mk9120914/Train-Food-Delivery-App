import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  ActivityIndicator, StyleSheet, ImageBackground, ScrollView
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFonts, Inter_900Black } from '@expo-google-fonts/inter';

export default function LoginScreen({ navigation }) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  let [fontsLoaded] = useFonts({ Inter_900Black });
  if (!fontsLoaded) return null;

  const handleLogin = async () => {
    if (username === '' || password === '') {
      setError('Please fill in both fields.');
      return;
    }

    setLoading(true);
    setError('');

    setTimeout(async () => {
      if (username === 'user' && password === 'password') {
        await AsyncStorage.setItem('user', JSON.stringify({ username }));
        setLoading(false);
        navigation.navigate('PNR'); 
      } else {
        navigation.navigate('PNR'); 
        setLoading(false);
        
        setError('Invalid credentials. Please try again.');
      }
    }, 1000);
  };

  const handleSignUp = async () => {
    if (!username || !password || !confirmPassword || !email || !name) {
      setError('All fields are required.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setLoading(true);
    setTimeout(async () => {
      await AsyncStorage.setItem('user', JSON.stringify({ username, name, email }));
      setLoading(false);
      navigation.replace('PNR');
    }, 1000);
  };

  return (
    <ImageBackground
      source={require('./assets/background.jpg')}
      style={styles.background}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>{isSignUp ? 'Create Account' : 'Login'}</Text>

        {isSignUp && (
          <>
            <TextInput style={styles.input} placeholder="Full Name" placeholderTextColor="#ccc" value={name} onChangeText={setName} />
            <TextInput style={styles.input} placeholder="Email" placeholderTextColor="#ccc" value={email} onChangeText={setEmail} keyboardType="email-address" />
          </>
        )}
        
        <TextInput style={styles.input} placeholder="Username" placeholderTextColor="#ccc" value={username} onChangeText={setUsername} />
        <TextInput style={styles.input} placeholder="Password" placeholderTextColor="#ccc" value={password} onChangeText={setPassword} secureTextEntry />
        
        {isSignUp && (
          <TextInput style={styles.input} placeholder="Confirm Password" placeholderTextColor="#ccc" value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry />
        )}

        {error !== '' && <Text style={styles.errorText}>{error}</Text>}

        <TouchableOpacity
          style={styles.button}
          onPress={isSignUp ? handleSignUp : handleLogin}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>{isSignUp ? 'Register' : 'Login'}</Text>}
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setIsSignUp(!isSignUp)}>
          <Text style={styles.toggleText}>
            {isSignUp ? 'Already have an account? Login' : 'New user? Create an account'}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 24,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Inter_900Black',
    color: 'white',
    textAlign: 'center',
    marginBottom: 30,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    color: 'white',
    borderRadius: 8,
    padding: 12,
    marginBottom: 15,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  button: {
    backgroundColor: '#FF6347',
    padding: 14,
    borderRadius: 25,
    alignItems: 'center',
    marginBottom: 15,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontFamily: 'Inter_900Black',
  },
  toggleText: {
    color: '#FFD700',
    fontSize: 14,
    textAlign: 'center',
    marginTop: 10,
  },
  errorText: {
    color: 'red',
    textAlign: 'center',
    marginBottom: 10,
  },
});
