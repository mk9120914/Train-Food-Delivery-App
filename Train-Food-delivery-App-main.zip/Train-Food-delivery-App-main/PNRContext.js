import React, { createContext, useContext, useState } from 'react';

// Create Context
const PNRContext = createContext();

// Custom Hook to use the PNR context
export const usePNR = () => useContext(PNRContext);

// Provider Component
export const PNRProvider = ({ children }) => {
  const [pnrData, setPnrData] = useState(null);

  return (
    <PNRContext.Provider value={{ pnrData, setPnrData }}>
      {children}
    </PNRContext.Provider>
  );
};
