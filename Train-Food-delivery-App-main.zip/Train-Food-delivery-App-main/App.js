import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';  // Import AsyncStorage
import { PNRProvider } from './PNRContext'; 
import PNRScreen from './PNRScreen';  
import HomeScreen from './HomeScreen';
import MenuScreen from './MenuScreen';
import OrderScreen from './OrderScreen';
import WalletScreen from './WalletScreen';
import LoginScreen from './loginScreen'; // Import Login Screen

const Stack = createStackNavigator();

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(null);  // Track login status

  // Check if user is already logged in
  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const user = await AsyncStorage.getItem('user');
        if (user) {
          setIsLoggedIn(true);  // User exists, set to true
        } else {
          setIsLoggedIn(false);  // No user found, set to false
        }
      } catch (error) {
        console.error('Error checking login status:', error);
      }
    };

    checkLoginStatus();
  }, []);

  if (isLoggedIn === null) {
    return null;  // Show nothing or a loading screen until we know the login status
  }

  return (
    <PNRProvider>  {/*Wrap the entire app in PNRProvider */}
      <NavigationContainer>
        <Stack.Navigator initialRouteName={"Login"}>
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
          <Stack.Screen name="PNR" component={PNRScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Menu" component={MenuScreen} />
          <Stack.Screen name="Order" component={OrderScreen} />
          <Stack.Screen name="Wallet" component={WalletScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </PNRProvider>
  );
}
