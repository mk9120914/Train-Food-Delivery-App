import React, { useState } from 'react';
import { 
  View, Text, TextInput, TouchableOpacity, 
  ActivityIndicator, StyleSheet, ImageBackground, Image, Alert 
} from 'react-native';
import { usePNR } from './PNRContext'; // Import Context
import { useFonts, Inter_900Black } from '@expo-google-fonts/inter';

export default function PNRScreen({ navigation }) {
  const [pnr, setPnr] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { setPnrData } = usePNR(); //  Use Context to Store PNR Data

  let [fontsLoaded] = useFonts({ Inter_900Black });

  if (!fontsLoaded) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FF6347" />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  const checkPNR = async () => {
    if (pnr.length !== 10) {
      setError('Please enter a valid 10-digit PNR number.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const response = await fetch(
        `https://irctc-indian-railway-pnr-status.p.rapidapi.com/getPNRStatus/${pnr}`,
        {
          method: 'GET',
          headers: {
            'x-rapidapi-host': 'irctc-indian-railway-pnr-status.p.rapidapi.com',
            'x-rapidapi-key': '52d7beed1fmsh29979ca2be3b933p13d183jsn137abb5d6355',
            'Accept': 'application/json'
          }
        }
      );

      const data = await response.json();
      setLoading(false);
      console.log('API Response:', JSON.stringify(data, null, 2)); // Debugging

      if (data.success) {
        const passengers = data.data.passengerList.map((passenger) => ({
          seatNumber: passenger.bookingBerthNo,
          coachNumber: passenger.bookingCoachId || 'Not Assigned',
          currentStatus: passenger.currentStatusDetails
        }));

        const arrivalTime = data.data.arrivalDate; // Expected arrival time

        //  Store extracted data in Context
        setPnrData({ passengers, arrivalTime });
        navigation.navigate('Home');  // Use replace() to clear back history
         
        
      } else {
        setError('Invalid PNR. No valid train details found.');
      }
    } catch (error) {
      setLoading(false);
      setError('Error fetching PNR details. Please try again.');
      console.error('API Error:', error);
    }
  };

  return (
    <ImageBackground source={require('./assets/background.jpg')} style={styles.background}>
      <View style={styles.container}>
        <Image source={require('./assets/logo.png')} style={styles.logo} />
        <Text style={styles.title}>Enter Your PNR</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter 10-digit PNR"
          keyboardType="numeric"
          maxLength={10}
          value={pnr}
          onChangeText={(text) => {
            setPnr(text);
            setError('');
          }}
          placeholderTextColor="#fff"
        />
        {error ? <Text style={styles.errorText}>{error}</Text> : null}

        <TouchableOpacity style={styles.button} onPress={checkPNR} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Check PNR</Text>}
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  loadingText: {
    color: '#FF6347',
    fontSize: 18,
    marginTop: 10,
  },
  container: {
    alignItems: 'center',
  },
  logo: {
    width: 120,
    height: 100,
    marginBottom: 40,
  },
  title: {
    fontSize: 45,
    marginBottom: 30,
    textAlign: 'center',
    color: 'white',
    fontFamily: 'Inter_900Black',
  },
  input: {
    width: '80%',
    height: 50,
    borderColor: '#fff',
    borderWidth: 2,
    borderRadius: 10,
    paddingHorizontal: 15,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    fontSize: 18,
    color: '#fff',
    marginBottom: 10,
    textAlign: 'center',
  },
  errorText: {
    color: '#FF6347',
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#FF6347',
    paddingVertical: 14,
    paddingHorizontal: 30,
    borderRadius: 30,
    marginVertical: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontFamily: 'Inter_900Black',
  },
});
