import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  ImageBackground,
  TouchableOpacity,
  Dimensions,
  Alert,
} from 'react-native';
import { useFonts, Inter_900Black } from '@expo-google-fonts/inter';

const initialMenuData = [
  { id: '1', name: 'Burger', description: 'Spicy Chicken burger', price: 90, image: require('./assets/burger.png'), stock: 3 },
  { id: '2', name: 'Pizza', description: 'Cheesy Mushroom pizza', price: 350, image: require('./assets/pizza.png'), stock: 2 },
  { id: '3', name: 'French Fries', description: 'Crispy Potato fries', price: 80, image: require('./assets/fries.png'), stock: 5 },
  { id: '4', name: 'Chicken Wings', description: 'Hot & Spicy Wings', price: 180, image: require('./assets/chickenwings.png'), stock: 4 },
  { id: '5', name: 'Menu Deal', description: 'Burger, fries & drink', price: 300, image: require('./assets/deal.png'), stock: 3 },
  { id: '6', name: 'Drinks', description: 'Coke, Fanta, Sprite', price: 99, image: require('./assets/drinks.png'), stock: 6 },
  { id: '7', name: 'Pasta', description: 'Creamy Alfredo pasta', price: 190, image: require('./assets/pasta.jpg'), stock: 3 },
  { id: '8', name: 'Tacos', description: 'Beef & Chicken tacos', price: 280, image: require('./assets/tacos.jpg'), stock: 3 },
  { id: '9', name: 'Ice Cream', description: 'Chocolate & Vanilla', price: 150, image: require('./assets/icecream.jpg'), stock: 5 },
];

const MenuScreen = () => {
  const screenWidth = Dimensions.get('window').width;
  const imageHeight = screenWidth * 0.18;

  let [fontsLoaded] = useFonts({
    Inter_900Black,
  });

  const [menuItems, setMenuItems] = useState(initialMenuData);
  const [cart, setCart] = useState({});

  if (!fontsLoaded) return null;

  const addToCart = (item) => {
    if (item.stock <= 0) return;

    const updatedMenu = menuItems.map((menuItem) =>
      menuItem.id === item.id ? { ...menuItem, stock: menuItem.stock - 1 } : menuItem
    );
    setMenuItems(updatedMenu);

    setCart((prevCart) => {
      const existing = prevCart[item.id];
      const newQuantity = existing ? existing.quantity + 1 : 1;
      const newTotal = newQuantity * item.price;

      return {
        ...prevCart,
        [item.id]: { quantity: newQuantity, total: newTotal, item },
      };
    });
  };

  const getTotalItems = () => {
    return Object.values(cart).reduce((acc, curr) => acc + curr.quantity, 0);
  };

  const getTotalPrice = () => {
    return Object.values(cart).reduce((acc, curr) => acc + curr.total, 0);
  };

  const handlePlaceOrder = () => {
    if (getTotalItems() === 0) return;

    Alert.alert(
      'Order Placed',
      `You ordered ${getTotalItems()} items worth Rs.${getTotalPrice()}`,
      [
        {
          text: 'OK',
          onPress: () => setCart({}),
        },
      ]
    );
  };

  const renderItem = ({ item }) => {
    const isOutOfStock = item.stock <= 0;

    return (
      <TouchableOpacity
        style={[styles.item, isOutOfStock && { opacity: 0.4 }]}
        onPress={() => addToCart(item)}
        disabled={isOutOfStock}
      >
        <ImageBackground
          source={item.image}
          style={[styles.imageBackground, { height: imageHeight }]}
          imageStyle={{ borderRadius: 8 }}
        >
          <View style={styles.itemInfo}>
            <Text style={styles.itemName}>{item.name}</Text>
            <Text style={styles.itemDescription}>{item.description}</Text>
            <Text style={styles.itemPrice}>Rs.{item.price}</Text>
            <Text style={styles.stockText}>
              {isOutOfStock ? 'Out of Stock' : `Stock: ${item.stock}`}
            </Text>
          </View>
        </ImageBackground>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Explore Our Delicious Menu</Text>

      <FlatList
        data={menuItems}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={3}
        columnWrapperStyle={styles.columnWrapper}
        showsVerticalScrollIndicator={false}
      />

      <View style={styles.cartSummary}>
        <Text style={styles.cartText}>Items: {getTotalItems()}</Text>
        <Text style={styles.cartText}>Total: Rs.{getTotalPrice()}</Text>
        <TouchableOpacity
          style={[styles.orderButton, getTotalItems() === 0 && { opacity: 0.5 }]}
          onPress={handlePlaceOrder}
          disabled={getTotalItems() === 0}
        >
          <Text style={styles.orderButtonText}>Place Order</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 12,
    paddingBottom: 80,
  },
  header: {
    fontSize: 22,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 8,
    fontFamily: 'Inter_900Black',
    textAlign: 'center',
  },
  columnWrapper: {
    justifyContent: 'space-between',
    paddingHorizontal: 4,
  },
  item: {
    flex: 1,
    margin: 6,
    borderRadius: 8,
    overflow: 'hidden',
  },
  imageBackground: {
    resizeMode: 'cover',
    justifyContent: 'flex-end',
    borderRadius: 8,
  },
  itemInfo: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    padding: 6,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
  },
  itemName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    fontFamily: 'Inter_900Black',
  },
  itemDescription: {
    color: '#ddd',
    fontSize: 10,
  },
  itemPrice: {
    color: '#FFD700',
    fontWeight: 'bold',
    fontSize: 12,
  },
  stockText: {
    color: '#bbb',
    fontSize: 10,
    marginTop: 2,
  },
  cartSummary: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#111',
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cartText: {
    color: 'white',
    fontSize: 14,
  },
  orderButton: {
    backgroundColor: '#FFD700',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  orderButtonText: {
    color: '#000',
    fontWeight: 'bold',
  },
});

export default MenuScreen;
