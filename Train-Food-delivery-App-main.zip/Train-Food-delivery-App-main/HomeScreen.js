import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ImageBackground, Image } from 'react-native';
import { useFonts, Inter_900Black } from '@expo-google-fonts/inter';
import { usePNR } from './PNRContext'; // Import PNR Context

const HomeScreen = ({ navigation }) => {
    let [fontsLoaded] = useFonts({ Inter_900Black });
    const { pnrData } = usePNR(); // Get PNR data from context

    if (!fontsLoaded) return null; 

    // Debugging: Log full PNR Data
    console.log("PNR Data:", JSON.stringify(pnrData, null, 2));

    // Extract passenger data correctly
    const passenger = pnrData?.passengers?.[0]; // Ensure correct reference

    console.log("Passenger Data:", passenger); // Debugging

    // Extract current status (seat info)
    const currentStatus = passenger?.currentStatus ?? "N/A"; // Ensure fallback value

    return (
        <ImageBackground source={require('./assets/background.jpg')} style={styles.background}>
            {/* Seat Status Box (Top Right) */}
            {pnrData && (
                <View style={styles.passengerInfo}>
                    <Text style={styles.passengerText}>🪑 Seat: {currentStatus}</Text>
                </View>
            )}

            <View style={styles.container}>
                {/* Logo */}
                <Image source={require('./assets/logo.png')} style={styles.logo} />
                <Text style={styles.welcomeText}>Welcome to RailFoods App!</Text>

                {/* Navigation Buttons */}
                <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Menu')}>
                    <Text style={styles.buttonText}>View Menu</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Order')}>
                    <Text style={styles.buttonText}>Your Order</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Wallet')}>
                    <Text style={styles.buttonText}>Your Wallet</Text>
                </TouchableOpacity>
            </View>
        </ImageBackground>
    );
};

const styles = StyleSheet.create({
    background: {
        flex: 1,
        resizeMode: 'cover',
        justifyContent: 'center',
        alignItems: 'center',
    },
    container: {
        alignItems: 'center',
        padding: 20,
    },
    logo: {
        width: 120,
        height: 100,
        marginBottom: 20,
    },
    welcomeText: {
        fontSize: 32,
        marginBottom: 30,
        textAlign: 'center',
        color: 'white',
        fontFamily: 'Inter_900Black',
        textShadowColor: 'rgba(0, 0, 0, 0.75)',
        textShadowOffset: { width: 2, height: 2 },
        textShadowRadius: 4,
    },
    passengerInfo: {
        position: 'absolute',
        top: 40,
        right: 20,
        backgroundColor: 'rgba(0, 0, 0, 0.8)', // Dark background for visibility
        paddingVertical: 8,
        paddingHorizontal: 12,
        borderRadius: 8,
        borderColor: '#FFD700', // Gold border for premium look
        borderWidth: 2,
        alignItems: 'center',
        justifyContent: 'center',
    },
    passengerText: {
        color: '#FFD700', // Gold color for seat info
        fontSize: 16,
        fontFamily: 'Inter_900Black',
    },
    button: {
        backgroundColor: '#FF6347',
        paddingVertical: 14,
        paddingHorizontal: 30,
        borderRadius: 30,
        marginVertical: 10,
        shadowColor: '#000',
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.5,
        shadowRadius: 3,
    },
    buttonText: {
        color: 'white',
        fontSize: 16,
        fontFamily: 'Inter_900Black',
    },
});

export default HomeScreen;
